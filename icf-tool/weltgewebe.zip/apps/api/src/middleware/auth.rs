use axum::{body::Body, extract::State, http::Request, middleware::Next, response::Response};
use axum_extra::extract::cookie::CookieJar;

use crate::{auth::role::Role, routes::auth::SESSION_COOKIE_NAME, state::ApiState};

#[derive(Clone, Debug)]
pub struct AuthContext {
    pub authenticated: bool,
    pub account_id: Option<String>,
    pub role: Role,
}

pub async fn auth_middleware(
    State(state): State<ApiState>,
    jar: CookieJar,
    mut request: Request<Body>,
    next: Next,
) -> Response {
    let mut ctx = AuthContext {
        authenticated: false,
        account_id: None,
        role: Role::Gast,
    };

    if let Some(cookie) = jar.get(SESSION_COOKIE_NAME) {
        if let Some(session) = state.sessions.get(cookie.value()) {
            if let Some(internal) = state.accounts.get(&session.account_id) {
                ctx.authenticated = true;
                ctx.account_id = Some(session.account_id);
                ctx.role = internal.role.clone();
            }
        }
    }

    request.extensions_mut().insert(ctx);
    next.run(request).await
}
